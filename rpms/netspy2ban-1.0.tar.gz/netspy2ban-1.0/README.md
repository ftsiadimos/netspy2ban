<h1 class='liketext'><img src="https://github.com/ftsiadimos/netspy2ban/blob/master/icons/netspy2ban.png" width="40" height="40"  margin-left: 4px alt="Logo" />NetSpy2Ban</h1>
 
NetSpy2Ban is a graphic user interface program for Fedora 22 OS. The program serves three functions. The first function is to view connected network cards and their speed. The second is to allow real time monitoring of your network connections. Lastly, NetSpy2Ban includes a graphic user interface to provide user-friendly functionality for the Fail2Ban service.

<a href="https://github.com/ftsiadimos/netspy2ban/blob/master/rpms/netspy2ban-1.0-1.fc22.noarch.rpm?raw=true" target="_blank">Download</a> the rpm file package for easy installation. Install the package through the software manager or with the following command through the terminal "sudo dnf install netspy2ban-1.0-1.fc22.noarch.rpm"

<br><br><p align="center">
<img src="https://github.com/ftsiadimos/netspy2ban/blob/master/icons/ima1.png" width="400" height="290" alt="image1"/><br>
<img src="https://github.com/ftsiadimos/netspy2ban/blob/master/icons/ima2.png" width="400" height="290" alt="image2"/><br>
<img src="https://github.com/ftsiadimos/netspy2ban/blob/master/icons/task1ima.png" width="300" height="140" alt="notify-image1"/><br>
<img src="https://github.com/ftsiadimos/netspy2ban/blob/master/icons/ima3.png" width="400" height="290" alt="imag3"/><br>
<img src="https://github.com/ftsiadimos/netspy2ban/blob/master/icons/task2ima.png" width="300" height="140" alt="notify-image2"/></p>
